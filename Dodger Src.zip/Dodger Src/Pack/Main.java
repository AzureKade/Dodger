package Pack;
import java.util.concurrent.ThreadLocalRandom;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import Pack.Ball;

public class Main extends JPanel {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//frame size
	public static int width;
	public static int height;
	public static Main game;
	
	//difficulty variables
	public enum Difficulty {EASY, MEDIUM, HARD, IMPOSSIBLE}
	public static Difficulty diffE;
	
	//player init
	public static int playerSize = 20;
	public static int playerx;
	public static int playery;
	public enum Direction {RIGHT , LEFT, NONE}
	public static Direction moveDir = Direction.NONE;
	public static float score = 0f;
	public static int playerSpeed;
	
	//ball value arrays
	public static int ballNum = 30;
	public static Ball[] ballArray = new Ball[ballNum]; 
	public static int[] bally = new int[ballNum];
	public static int[] ballx = new int[ballNum];
	public static float[] ballSpeed = new float[ballNum];
	public static float speed;
	public static int[] ballSize = new int[ballNum];
	public static int size;
	
	
	//loose screen values
	public static boolean hasLost = false;
	public static boolean drawTimer = true;
	public static int time = 3;
	
	public static void main(String[] args) throws InterruptedException
	{ 
		//game frame variables
		JFrame gFrame = new JFrame("Dodger");
		gFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		width = 1000;
		height = 600;
		int x = ((int)screenSize.getWidth()/2)-(width/2);
		int y = ((int)screenSize.getHeight()/2)-(height/2);
		
		//player
		playerx = width/2 - playerSize/2;
		playery = height - 70 - playerSize;		
		
		game = new Main();
		
		//game difficulty set
		diffE = Difficulty.EASY;
		Object[] options = {"Easy", "Medium", "Hard", "Impossible"};
		int diff = JOptionPane.showOptionDialog(gFrame, "Select difficulty", "Difficulty",
				   JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE,
				   null, options, options[0]);
		if(diff == 0) diffE = Difficulty.EASY;
		else if(diff == 1) diffE = Difficulty.MEDIUM;
		else if(diff == 2) diffE = Difficulty.HARD;
		else if(diff == 3) diffE = Difficulty.IMPOSSIBLE;
		else System.exit(0);
		setDiff(diffE);
		
		//show game frame
		gFrame.add(game);
		gFrame.setBounds(x, y, width, height);
		gFrame.setVisible(true);
		gFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//Player movement listener
		gFrame.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == KeyEvent.VK_RIGHT) moveDir = Direction.RIGHT; 
				else if(e.getKeyCode() == KeyEvent.VK_LEFT) moveDir = Direction.LEFT;				
				else moveDir = Direction.NONE;
			}
			public void keyReleased(KeyEvent e) 
			{
				moveDir = Direction.NONE;
			}
		});
		
		//Update and draw game frame
		boolean collision;
		while (true) {
			
			//draw timer
			for(int i = time; i > 0; i--)
			{
				game.repaint();
				Thread.sleep(1000);
				time -= 1;
			}
			drawTimer = false;
			
			game.movePlayer(playerSpeed);
			game.moveBalls();
			collision = game.checkColl();
			if(collision) 
			{
				hasLost = true;
				game.repaint();
				Thread.sleep(5000);
				gFrame.setVisible(false);
				askPlayAgain();
				break;
			}
			score += 0.01f;
			game.repaint();
			Thread.sleep(10);
		}
		
		//System.exit(0);
	}

	private static void askPlayAgain() throws InterruptedException {
		Object[] options = {"Try Again", "Quit"};
		int opt = JOptionPane.showOptionDialog(null, "Would you like to try again?", "Game Over",
				   JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE,
				   null, options, options[1]);
		if(opt == 0) 
		{
			hasLost = false;
			drawTimer = true;
			time = 3;
			score = 0;
			game = new Main();
			main(null);
		}
		else if(opt == 1) System.exit(0);
	}

	private void drawTimer(Graphics g) {
		//background
		super.paint(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(Color.BLACK);
		g2d.fillRect(0, 0, width, height);
		g2d.setColor(Color.GREEN);		
		g2d.fillRect(0, height - 70, width, 50);
		
		//player
		g2d.setColor(Color.WHITE);
		g2d.fillRect(playerx, playery, playerSize,playerSize);	
		
		//timer
		Font f = new Font("Verdana", Font.PLAIN, 46);
		g2d.setFont(f);
		g2d.drawString("" + time, width/2 - 16, height/2 - 23);
	}
	
	public void paintLose(Graphics l) 
	{
		//background
		Graphics2D g2d = (Graphics2D) l;
		g2d.setColor(Color.WHITE);
		g2d.fillRect(0, 0, width, height);
		
		//loose text
		Font f = new Font("Verdana", Font.PLAIN, 60);
		g2d.setColor(Color.RED);
		g2d.setFont(f);
		g2d.drawString("You Died!", 20, 100);
		
		g2d.setColor(Color.BLACK);
		
		//score
		g2d.drawString("Score: " + (int)score, 20, 200);
		
		//difficulty
		g2d.drawString("Difficulty: " + diffE, 20, 300);
	}
	
	public void paintGame(Graphics l) 
	{
		//background
		Graphics2D g2d = (Graphics2D) l;
		g2d.setColor(Color.BLACK);
		g2d.fillRect(0, 0, width, height);
		g2d.setColor(Color.GREEN);		
		g2d.fillRect(0, height - 70, width, 50);
		
		//score
		Font f = new Font("Verdana", Font.PLAIN, 30);
		g2d.setColor(Color.WHITE);
		g2d.setFont(f);
		g2d.drawString((int)score + "", width - 70, 30);
		
		
		//player
		g2d.setColor(Color.WHITE);
		g2d.fillRect(playerx, playery, playerSize,playerSize);	
		
		//balls
		g2d.setColor(Color.RED);
		for(int i = 0; i < ballArray.length; i++) 
		{
			g2d.fillRect(ballx[i], bally[i], ballSize[i], ballSize[i]);
		}
	}
	
	@Override
	public void paint(Graphics g) 
	{	
		//background
		super.paint(g);
		if(hasLost) paintLose(g);
		else if(drawTimer) drawTimer(g);
		else paintGame(g);
		
	}
	
	public void movePlayer(int _speed) 
	{
		int movement = 0;
		switch (moveDir) //you want switch statements, i got 'em
		{
			case RIGHT: movement += _speed;
				break;
			case LEFT: movement -= _speed;
				break;
			case NONE: movement = 0;
				break;
			default: movement = 0;
				break;
		}
		playerx += movement;
	}
	
	public void moveBalls() 
	{
		
		for(int i = 0; i < ballArray.length; i++) 
		{
			bally[i] += ballSpeed[i];
			if(bally[i] >= (height - 70 - ballSize[i])) 
			{
				bally[i] = ThreadLocalRandom.current().nextInt(-1 * height, 0);
				ballx[i] = ThreadLocalRandom.current().nextInt(1, width + 1);
				ballSize[i] = ThreadLocalRandom.current().nextInt(size, size + 10);
				ballSpeed[i] = speed + (ThreadLocalRandom.current().nextFloat()*2);
			}
		}
	}
	
	public boolean checkColl() 
	{
		for(int i = 0; i < ballArray.length; i++) 
		{
			for(int y = 0; y <= ballSize[i]; y++)
			{
				if(bally[i] + y == playery || bally[i] + y == playery + playerSize)
				{
					for(int x = 0; x <= ballSize[i]; x++)
					{
						if(ballx[i] + x == playerx || ballx[i] + x == playerx + playerSize)
						{
					        return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	public static void setDiff(Difficulty diff) 
	{
		switch (diff) 
		{
		case EASY: ballInit(35, 3f);
				   playerSpeed = 2;
				   break;
		case MEDIUM: ballInit(40, 3f);
					 playerSpeed = 2;
		             break;
		case HARD: ballInit(45, 4f);
				   playerSpeed = 3;
		           break;
		case IMPOSSIBLE: ballInit(50, 6f);
						 playerSpeed = 4;
		                 break;
		default:
			break;
		} 
	}
	
	
	public static void ballInit(int _size, float _speed) 
	{
		for(int i = 0; i < ballArray.length; i++) 
		{
			ballArray[i] = new Ball(ThreadLocalRandom.current().nextInt(1, width + 1),
									ThreadLocalRandom.current().nextInt(-2 * height, 0),
									ThreadLocalRandom.current().nextInt(_size, _size + 10),
									_speed + (ThreadLocalRandom.current().nextFloat()*2));
			ballx[i] = ballArray[i].x;
			bally[i] = ballArray[i].y;
			ballSize[i] = ballArray[i].size;
			ballSpeed[i] = ballArray[i].speed;
			size = _size;
			speed = _speed;
		}
	}
	
}
