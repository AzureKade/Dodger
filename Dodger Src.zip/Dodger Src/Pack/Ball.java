package Pack;

public class Ball {
	
	public int x;
	public int y;
	public int size;
	public float speed;
	
	public Ball(int startx, int starty, int _size, float _speed) 
	{
		x = startx;
		y = starty;
		size = _size;
		speed = _speed;
	}
}
